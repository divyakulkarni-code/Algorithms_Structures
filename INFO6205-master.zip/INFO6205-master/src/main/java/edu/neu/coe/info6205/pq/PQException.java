/*
 * Copyright (c) 2017. Phasmid Software
 */

package edu.neu.coe.info6205.pq;

public class PQException extends Exception {
    public PQException(String msg) {
        super(msg);
    }
}
