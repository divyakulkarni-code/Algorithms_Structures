package edu.neu.coe.info6205.sort.simple;

public class Solution {
    public static void main(String[] args) {
        int[] array = {9, 8, 7, 6, 5, 4, 3, 2, 1};
        int res = Solution.binarySearch(array, 3);
        System.out.println(res);
    }

    static int binarySearch(int[] array, int key) {
        // TO BE IMPLEMENTED
        return -1;

    }


}